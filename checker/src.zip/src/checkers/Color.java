package checkers;

/**
 * Color of the piece.
 */
public enum Color {
  BLACK, WHITE
}

